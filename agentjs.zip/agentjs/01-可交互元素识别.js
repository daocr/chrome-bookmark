(function () {
    // ==========================================
    // 1. 配置与常量
    // ==========================================
    const OVERLAY_ID = 'llm-browser-agent-overlay'; // 可视化层的唯一 ID
    const CONFIG = {
        MIN_WIDTH: 5,
        MIN_HEIGHT: 5,
        // 交互标签白名单
        INTERACTIVE_TAGS: new Set(['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'DETAILS', 'SUMMARY']),
        // 交互 Role 白名单
        INTERACTIVE_ROLES: new Set(['button', 'link', 'checkbox', 'menuitem', 'menuitemcheckbox', 'radio', 'tab', 'textbox', 'combobox', 'searchbox']),
        // 排除的 Input 类型
        EXCLUDE_TYPES: new Set(['hidden', 'image'])
    };

    let uniqueIdCounter = 1;

    // ==========================================
    // 2. 感知模块 (Perception Logic)
    // ==========================================

    /**
     * 递归遍历 DOM，穿透 Shadow Root
     * 同时忽略可视化层自身，防止递归死循环或数据污染
     */
    function deepQuerySelectorAll(root) {
        let allElements = [];

        // 获取当前层级所有元素
        const els = root.querySelectorAll('*');

        els.forEach(el => {
            // [关键修正]：如果遇到我们自己画的框，直接跳过，不扫描
            if (el.id === OVERLAY_ID || el.closest(`#${OVERLAY_ID}`)) return;

            allElements.push(el);

            // 递归进入 Shadow DOM
            if (el.shadowRoot) {
                const shadowElements = deepQuerySelectorAll(el.shadowRoot);
                allElements = allElements.concat(shadowElements);
            }
        });

        return allElements;
    }

    function isVisible(el, style, rect) {
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
        if (rect.width < CONFIG.MIN_WIDTH || rect.height < CONFIG.MIN_HEIGHT) return false;
        if (el.tagName === 'INPUT' && CONFIG.EXCLUDE_TYPES.has(el.type)) return false;
        return true;
    }

    function isInteractive(el, style) {
        if (CONFIG.INTERACTIVE_TAGS.has(el.tagName)) return true;
        const role = el.getAttribute('role');
        if (role && CONFIG.INTERACTIVE_ROLES.has(role)) return true;
        if (style.cursor === 'pointer') return true; // 强特征
        if (el.getAttribute('contenteditable') === 'true') return true;
        if (el.getAttribute('tabindex') && parseInt(el.getAttribute('tabindex')) >= 0) return true;
        return false;
    }

    function getElementLabel(el) {
        let text = el.getAttribute('aria-label') ||
            el.getAttribute('placeholder') ||
            el.innerText ||
            el.getAttribute('title') ||
            "";
        return text.replace(/\s+/g, ' ').trim().slice(0, 100);
    }

    function scanPage() {
        console.time("ScanTime");
        const allElements = deepQuerySelectorAll(document);
        const perceptionData = [];
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;

        allElements.forEach(el => {
            const style = window.getComputedStyle(el);
            const rect = el.getBoundingClientRect();

            if (!isVisible(el, style, rect)) return;
            if (!isInteractive(el, style)) return;

            // 标记 ID (复用或新建)
            let llmId = el.getAttribute('data-llm-id');
            if (!llmId) {
                llmId = String(uniqueIdCounter++);
                el.setAttribute('data-llm-id', llmId);
            }

            const inViewport = (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= viewportHeight &&
                rect.right <= viewportWidth
            );

            perceptionData.push({
                id: llmId,
                tag: el.tagName.toLowerCase(),
                type: el.tagName === 'INPUT' ? el.type : null,
                text: getElementLabel(el),
                rect: {
                    x: Math.round(rect.x),
                    y: Math.round(rect.y),
                    w: Math.round(rect.width),
                    h: Math.round(rect.height)
                },
                inViewport: inViewport,
                isShadow: !!el.getRootNode().host // 标记是否在 Shadow DOM 内
            });
        });

        console.timeEnd("ScanTime");
        return perceptionData;
    }

    // ==========================================
    // 3. 可视化模块 (Visualization Logic)
    // ==========================================

    function drawBoundingBoxes(elements) {
        // 清理旧层
        const existingOverlay = document.getElementById(OVERLAY_ID);
        if (existingOverlay) existingOverlay.remove();

        // 创建容器
        const overlay = document.createElement('div');
        overlay.id = OVERLAY_ID;
        Object.assign(overlay.style, {
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100vw',
            height: '100vh',
            zIndex: '2147483647',
            pointerEvents: 'none', // 允许点击穿透
            overflow: 'hidden'
        });

        let drawCount = 0;
        elements.forEach(item => {
            if (!item.inViewport) return;

            const {x, y, w, h} = item.rect;

            // 盒子
            const box = document.createElement('div');
            Object.assign(box.style, {
                position: 'absolute',
                left: `${x}px`,
                top: `${y}px`,
                width: `${w}px`,
                height: `${h}px`,
                border: '2px solid #ff0042',
                backgroundColor: 'rgba(255, 0, 66, 0.05)',
                borderRadius: '2px',
                boxSizing: 'border-box'
            });

            // 标签
            const label = document.createElement('div');
            label.innerText = item.id;
            Object.assign(label.style, {
                position: 'absolute',
                top: '-20px',
                left: '-2px',
                backgroundColor: '#ff0042',
                color: 'white',
                fontSize: '12px',
                fontWeight: 'bold',
                padding: '1px 5px',
                borderRadius: '2px',
                whiteSpace: 'nowrap',
                zIndex: '10'
            });

            // 边缘修正：如果在屏幕最顶端，标签放里面
            if (y < 20) label.style.top = '0';

            // Shadow DOM 元素用不同颜色 (青色)
            if (item.isShadow) {
                const cyan = '#00e5ff';
                box.style.borderColor = cyan;
                box.style.backgroundColor = 'rgba(0, 229, 255, 0.05)';
                label.style.backgroundColor = cyan;
                label.style.color = 'black';
            }

            box.appendChild(label);
            overlay.appendChild(box);
            drawCount++;
        });

        document.body.appendChild(overlay);
        console.log(`[Visualization] 已绘制 ${drawCount} 个元素 (红色=普通, 青色=ShadowDOM)`);
    }

    // ==========================================
    // 4. 执行入口
    // ==========================================

    console.log("🚀 开始感知页面...");

    // 1. 扫描
    const data = scanPage();

    // 2. 绘制
    drawBoundingBoxes(data);

    // 3. 返回数据供查看
    console.log("📋 最终感知数据:", data);
    return data;

})();