(function() {
    const OVERLAY_ID = 'llm-browser-agent-overlay';
    const CONFIG = {
        MIN_WIDTH: 5,
        MIN_HEIGHT: 5,
        INTERACTIVE_TAGS: new Set(['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'DETAILS', 'SUMMARY']),
        INTERACTIVE_ROLES: new Set(['button', 'link', 'checkbox', 'menuitem', 'menuitemcheckbox', 'radio', 'tab', 'textbox', 'combobox', 'searchbox']),
        TEXT_TAGS: new Set(['H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'P', 'SPAN', 'DIV', 'LABEL', 'LI', 'TD', 'TH', 'PRE', 'CODE', 'B', 'STRONG', 'I', 'EM'])
    };

    let uniqueIdCounter = 1;

    // --- 工具函数 ---

    function deepQuerySelectorAll(root) {
        let allElements = [];
        const els = root.querySelectorAll('*');
        els.forEach(el => {
            if (el.id === OVERLAY_ID || el.closest(`#${OVERLAY_ID}`)) return;
            allElements.push(el);
            if (el.shadowRoot) {
                allElements = allElements.concat(deepQuerySelectorAll(el.shadowRoot));
            }
        });
        return allElements;
    }

    function isVisible(el, style, rect) {
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
        if (rect.width < 1 || rect.height < 1) return false;
        return true;
    }

    function isInteractive(el, style) {
        if (CONFIG.INTERACTIVE_TAGS.has(el.tagName)) return true;
        const role = el.getAttribute('role');
        if (role && CONFIG.INTERACTIVE_ROLES.has(role)) return true;
        if (style.cursor === 'pointer') return true;
        if (el.getAttribute('contenteditable') === 'true') return true;
        if (el.getAttribute('tabindex') && parseInt(el.getAttribute('tabindex')) >= 0) return true;
        return false;
    }

    function isMeaningfulText(el, style) {
        if (!CONFIG.TEXT_TAGS.has(el.tagName)) return false;
        // 排除含有块级子元素的容器 (初步过滤)
        const hasBlockChildren = Array.from(el.children).some(child => {
            const childStyle = window.getComputedStyle(child);
            return childStyle.display === 'block' || childStyle.display === 'flex' || childStyle.display === 'grid';
        });
        if (hasBlockChildren) return false;

        const text = (el.innerText || el.textContent || "").trim();
        if (text.length === 0) return false;
        if (text.length > 5000) return false;
        return true;
    }

    function getElementLabel(el, isInput) {
        let text = "";
        if (isInput) {
            if (el.id) {
                const labelEl = document.querySelector(`label[for="${el.id}"]`);
                if (labelEl) text = labelEl.innerText || labelEl.textContent;
            }
            if (!text) text = el.getAttribute('aria-label') || el.getAttribute('placeholder');
        } else {
            text = el.innerText || el.textContent;
        }
        return String(text || "").replace(/[\n\r]+/g, ' ').replace(/\s{2,}/g, ' ').trim().slice(0, 200);
    }

    /**
     * [新增] 去重算法：解决 div 包裹 span 导致的数据重复
     */
    function filterDuplicates(data) {
        const groups = {};

        // 1. 分组：将位置和内容完全一样的归为一组
        data.forEach(item => {
            // 生成指纹: "x,y,w,h|text"
            const key = `${item.rect.x},${item.rect.y},${item.rect.w},${item.rect.h}|${item.text}`;
            if (!groups[key]) {
                groups[key] = [];
            }
            groups[key].push(item);
        });

        const result = [];

        // 2. 组内 PK：每组只选一个最好的
        Object.values(groups).forEach(group => {
            if (group.length === 1) {
                result.push(group[0]);
            } else {
                // 有重复，进行排序，保留 score 最高的
                group.sort((a, b) => {
                    // 优先级 A: 交互元素 > 纯文本
                    const scoreA_Interact = a.category !== 'text' ? 10 : 0;
                    const scoreB_Interact = b.category !== 'text' ? 10 : 0;
                    if (scoreA_Interact !== scoreB_Interact) return scoreB_Interact - scoreA_Interact;

                    // 优先级 B: 语义标签 (span, p, h1) > 通用容器 (div)
                    const isGenericA = ['div', 'section', 'article'].includes(a.tag);
                    const isGenericB = ['div', 'section', 'article'].includes(b.tag);
                    if (isGenericA && !isGenericB) return 1; // B 赢 (A 是通用的，沉底)
                    if (!isGenericA && isGenericB) return -1; // A 赢

                    // 优先级 C: ID 越大越好 (通常 ID 大意味着是子节点/叶子节点，更精准)
                    return parseInt(b.id) - parseInt(a.id);
                });

                // 取出冠军，其他的丢弃
                const winner = group[0];
                result.push(winner);
            }
        });

        // 恢复原始 ID 顺序 (可选)
        return result.sort((a, b) => parseInt(a.id) - parseInt(b.id));
    }

    // --- 主逻辑 ---

    function scanPage() {
        console.time("ScanTime");
        const allElements = deepQuerySelectorAll(document);
        const rawData = [];
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;

        allElements.forEach(el => {
            let style, rect;
            try {
                style = window.getComputedStyle(el);
                rect = el.getBoundingClientRect();
            } catch (e) { return; }

            if (!isVisible(el, style, rect)) return;

            const interactive = isInteractive(el, style);
            const meaningfulText = !interactive && isMeaningfulText(el, style);

            if (!interactive && !meaningfulText) return;

            // ID 处理
            let llmId = el.getAttribute('data-llm-id');
            if (!llmId) {
                llmId = String(uniqueIdCounter++);
                el.setAttribute('data-llm-id', llmId);
            }

            const inViewport = (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= viewportHeight &&
                rect.right <= viewportWidth
            );

            let category = 'text';
            if (interactive) {
                category = (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') ? 'input' : 'clickable';
            }

            rawData.push({
                id: llmId,
                tag: el.tagName.toLowerCase(),
                category: category,
                text: getElementLabel(el, category === 'input'),
                rect: {
                    x: Math.round(rect.x),
                    y: Math.round(rect.y),
                    w: Math.round(rect.width),
                    h: Math.round(rect.height)
                },
                inViewport: inViewport,
                isShadow: !!el.getRootNode().host
            });
        });

        // [关键步骤] 执行去重
        const cleanData = filterDuplicates(rawData);

        console.timeEnd("ScanTime");
        console.log(`[Perception] 原始扫描: ${rawData.length}, 去重后: ${cleanData.length}`);
        return cleanData;
    }

    // --- 可视化 ---
    function drawBoundingBoxes(elements) {
        const existingOverlay = document.getElementById(OVERLAY_ID);
        if (existingOverlay) existingOverlay.remove();

        const overlay = document.createElement('div');
        overlay.id = OVERLAY_ID;
        Object.assign(overlay.style, {
            position: 'fixed', top: '0', left: '0', width: '100vw', height: '100vh',
            zIndex: '2147483647', pointerEvents: 'none', overflow: 'hidden'
        });

        elements.forEach(item => {
            if (!item.inViewport) return;
            const { x, y, w, h } = item.rect;
            const box = document.createElement('div');

            const isText = item.category === 'text';
            const color = isText ? '#2196F3' : '#ff0042';
            const borderStyle = isText ? 'dashed' : 'solid';

            Object.assign(box.style, {
                position: 'absolute', left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${h}px`,
                border: `1px ${borderStyle} ${color}`,
                backgroundColor: isText ? 'transparent' : 'rgba(255, 0, 66, 0.05)',
                borderRadius: '2px', boxSizing: 'border-box'
            });

            if (!isText) {
                const label = document.createElement('div');
                label.innerText = item.id;
                Object.assign(label.style, {
                    position: 'absolute', top: '-18px', left: '-1px',
                    backgroundColor: color, color: 'white', fontSize: '10px',
                    padding: '0 4px', borderRadius: '2px'
                });
                if (y < 20) label.style.top = '0';
                box.appendChild(label);
            }

            overlay.appendChild(box);
        });
        document.body.appendChild(overlay);
    }

    // 执行
    const data = scanPage();
    drawBoundingBoxes(data);
    return data;
})();