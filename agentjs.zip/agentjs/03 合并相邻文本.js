(function() {
    const OVERLAY_ID = 'llm-browser-agent-overlay';
    const CONFIG = {
        MIN_WIDTH: 5,
        MIN_HEIGHT: 5,
        INTERACTIVE_TAGS: new Set(['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'DETAILS', 'SUMMARY']),
        INTERACTIVE_ROLES: new Set(['button', 'link', 'checkbox', 'menuitem', 'menuitemcheckbox', 'radio', 'tab', 'textbox', 'combobox', 'searchbox']),
        TEXT_TAGS: new Set(['H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'P', 'SPAN', 'DIV', 'LABEL', 'LI', 'TD', 'TH', 'PRE', 'CODE', 'B', 'STRONG', 'I', 'EM', 'FONT', 'BLOCKQUOTE'])
    };

    let uniqueIdCounter = 1;

    // --- 基础工具函数 (保持不变) ---
    function deepQuerySelectorAll(root) {
        let allElements = [];
        const els = root.querySelectorAll('*');
        els.forEach(el => {
            if (el.id === OVERLAY_ID || el.closest(`#${OVERLAY_ID}`)) return;
            allElements.push(el);
            if (el.shadowRoot) allElements = allElements.concat(deepQuerySelectorAll(el.shadowRoot));
        });
        return allElements;
    }

    function isVisible(el, style, rect) {
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
        if (rect.width < 1 || rect.height < 1) return false;
        return true;
    }

    function isInteractive(el, style) {
        if (CONFIG.INTERACTIVE_TAGS.has(el.tagName)) return true;
        const role = el.getAttribute('role');
        if (role && CONFIG.INTERACTIVE_ROLES.has(role)) return true;
        if (style.cursor === 'pointer') return true;
        if (el.getAttribute('contenteditable') === 'true') return true;
        if (el.getAttribute('tabindex') && parseInt(el.getAttribute('tabindex')) >= 0) return true;
        return false;
    }

    function isMeaningfulText(el, style) {
        if (!CONFIG.TEXT_TAGS.has(el.tagName)) return false;
        const hasBlockChildren = Array.from(el.children).some(child => {
            const childStyle = window.getComputedStyle(child);
            return childStyle.display === 'block' || childStyle.display === 'flex' || childStyle.display === 'grid';
        });
        if (hasBlockChildren) return false;
        const text = (el.innerText || el.textContent || "").trim();
        if (text.length === 0 || text.length > 10000) return false;
        return true;
    }

    function getElementLabel(el, isInput) {
        let text = "";
        if (isInput) {
            if (el.id) {
                const labelEl = document.querySelector(`label[for="${el.id}"]`);
                if (labelEl) text = labelEl.innerText || labelEl.textContent;
            }
            if (!text) text = el.getAttribute('aria-label') || el.getAttribute('placeholder');
        } else {
            text = el.innerText || el.textContent;
        }
        return String(text || "").replace(/[\n\r]+/g, ' ').replace(/\s{2,}/g, ' ').trim().slice(0, 500); // 增加长度限制以便合并
    }

    // --- 步骤1: 去重 (保持不变) ---
    function filterDuplicates(data) {
        const groups = {};
        data.forEach(item => {
            const key = `${item.rect.x},${item.rect.y},${item.rect.w},${item.rect.h}|${item.text}`;
            if (!groups[key]) groups[key] = [];
            groups[key].push(item);
        });

        const result = [];
        Object.values(groups).forEach(group => {
            if (group.length === 1) {
                result.push(group[0]);
            } else {
                group.sort((a, b) => {
                    const scoreA = a.category !== 'text' ? 10 : 0;
                    const scoreB = b.category !== 'text' ? 10 : 0;
                    if (scoreA !== scoreB) return scoreB - scoreA;

                    const isGenericA = ['div', 'section'].includes(a.tag);
                    const isGenericB = ['div', 'section'].includes(b.tag);
                    if (isGenericA && !isGenericB) return 1;
                    if (!isGenericA && isGenericB) return -1;

                    return parseInt(b.id) - parseInt(a.id);
                });
                result.push(group[0]);
            }
        });
        return result.sort((a, b) => parseInt(a.id) - parseInt(b.id));
    }

    /**
     * --- [修正] 步骤2: 聚合 (Text Clustering) ---
     * 策略升级：将文本和非文本分开处理，防止交互元素打断文本合并
     */
    function mergeNearbyText(data) {
        if (data.length === 0) return [];

        // 1. 分离轨道：文本 vs 其他
        const textNodes = data.filter(item => item.category === 'text');
        const otherNodes = data.filter(item => item.category !== 'text');

        // 2. 仅对文本进行排序 (先 Y 轴，后 X 轴)
        textNodes.sort((a, b) => a.rect.y - b.rect.y || a.rect.x - b.rect.x);

        const mergedTexts = [];
        if (textNodes.length === 0) return otherNodes;

        let current = textNodes[0];

        for (let i = 1; i < textNodes.length; i++) {
            const next = textNodes[i];

            // 宽松系数
            const X_TOLERANCE = 20; // 允许稍微有点缩进差异
            const Y_GAP_TOLERANCE = 60; // 允许段落间距 (增加到了60px)

            // 判断
            const isAlignedX = Math.abs(current.rect.x - next.rect.x) < X_TOLERANCE;
            // 宽度差异不能太离谱 (防止合并了侧边栏的小字)
            const isWidthSimilar = Math.abs(current.rect.w - next.rect.w) < 200;

            const currentBottom = current.rect.y + current.rect.h;
            const gap = next.rect.y - currentBottom;

            // gap >= -10 允许轻微的重叠 (bounding box 有时候不准)
            const isCloseY = gap >= -10 && gap < Y_GAP_TOLERANCE;

            if (isAlignedX && isCloseY && isWidthSimilar) {
                // === 执行合并 ===
                current.text += "\n" + next.text; // 加个换行符连接

                // 更新几何信息
                const newBottom = next.rect.y + next.rect.h;
                current.rect.h = newBottom - current.rect.y;
                current.rect.w = Math.max(current.rect.w, next.rect.w);

                // 保持 current 不变，继续向后吞噬
            } else {
                // 无法合并，归档 current，开启新的 current
                mergedTexts.push(current);
                current = next;
            }
        }
        mergedTexts.push(current);

        // 3. 将合并后的文本和原始的交互元素合体，并恢复顺序
        const finalResult = [...mergedTexts, ...otherNodes];

        // 重新按 ID 排序，或者按 Y 轴视觉顺序排序
        // 这里按 Y 轴排序比较符合人类直觉
        return finalResult.sort((a, b) => a.rect.y - b.rect.y);
    }

    // --- 主逻辑 ---
    function scanPage() {
        console.time("ScanTotal");
        const allElements = deepQuerySelectorAll(document);
        let rawData = [];
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;

        allElements.forEach(el => {
            let style, rect;
            try {
                style = window.getComputedStyle(el);
                rect = el.getBoundingClientRect();
            } catch (e) { return; }

            if (!isVisible(el, style, rect)) return;

            const interactive = isInteractive(el, style);
            const meaningfulText = !interactive && isMeaningfulText(el, style);

            if (!interactive && !meaningfulText) return;

            let llmId = el.getAttribute('data-llm-id');
            if (!llmId) {
                llmId = String(uniqueIdCounter++);
                el.setAttribute('data-llm-id', llmId);
            }

            const inViewport = (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= viewportHeight &&
                rect.right <= viewportWidth
            );

            let category = 'text';
            if (interactive) category = (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') ? 'input' : 'clickable';

            rawData.push({
                id: llmId,
                tag: el.tagName.toLowerCase(),
                category: category,
                text: getElementLabel(el, category === 'input'),
                rect: {
                    x: Math.round(rect.x), y: Math.round(rect.y),
                    w: Math.round(rect.width), h: Math.round(rect.height)
                },
                inViewport: inViewport,
                isShadow: !!el.getRootNode().host
            });
        });

        // 1. 去重
        let processedData = filterDuplicates(rawData);

        // 2. 聚合 (关键修复步骤)
        processedData = mergeNearbyText(processedData);

        console.log(`[Perception] 最终元素数量: ${processedData.length}`);
        console.timeEnd("ScanTotal");
        return processedData;
    }

    // --- 可视化 ---
    function drawBoundingBoxes(elements) {
        const existingOverlay = document.getElementById(OVERLAY_ID);
        if (existingOverlay) existingOverlay.remove();

        const overlay = document.createElement('div');
        overlay.id = OVERLAY_ID;
        Object.assign(overlay.style, {
            position: 'fixed', top: '0', left: '0', width: '100vw', height: '100vh',
            zIndex: '2147483647', pointerEvents: 'none', overflow: 'hidden'
        });

        elements.forEach(item => {
            if (!item.inViewport) return;
            const { x, y, w, h } = item.rect;
            const box = document.createElement('div');

            const isText = item.category === 'text';
            const color = isText ? '#2196F3' : '#ff0042';
            const borderStyle = isText ? 'dashed' : 'solid';

            Object.assign(box.style, {
                position: 'absolute', left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${h}px`,
                border: `1px ${borderStyle} ${color}`,
                backgroundColor: isText ? 'transparent' : 'rgba(255, 0, 66, 0.05)',
                borderRadius: '2px', boxSizing: 'border-box'
            });

            if (!isText) {
                const label = document.createElement('div');
                label.innerText = item.id;
                Object.assign(label.style, {
                    position: 'absolute', top: '-18px', left: '-1px',
                    backgroundColor: color, color: 'white', fontSize: '10px',
                    padding: '0 4px', borderRadius: '2px'
                });
                if (y < 20) label.style.top = '0';
                box.appendChild(label);
            }

            overlay.appendChild(box);
        });
        document.body.appendChild(overlay);
    }

    const data = scanPage();
    drawBoundingBoxes(data);
    return data;
})();