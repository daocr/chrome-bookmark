(function () {
    /**
     * LLM Browser Agent Perception Module (Console Ready)
     * 核心逻辑：扫描 -> 过滤（遮挡检测） -> 语义化 -> 聚合 -> 渲染
     */
    class BrowserPerceiver {
        constructor() {
            this.OVERLAY_ID = 'llm-browser-agent-overlay';
            // 持久化 ID 逻辑：尝试从现有 DOM 恢复计数
            const existingMaxId = Array.from(document.querySelectorAll('[data-llm-id]'))
                .map(el => parseInt(el.getAttribute('data-llm-id')))
                .filter(id => !isNaN(id));
            this.uniqueIdCounter = existingMaxId.length > 0 ? Math.max(...existingMaxId) + 1 : 1;

            this.CONFIG = {
                INTERACTIVE_TAGS: new Set(['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'DETAILS', 'SUMMARY']),
                INTERACTIVE_ROLES: new Set(['button', 'link', 'checkbox', 'menuitem', 'tab', 'textbox', 'switch', 'radio']),
                TEXT_TAGS: new Set(['P', 'SPAN', 'DIV', 'LABEL', 'TD', 'TH', 'B', 'STRONG', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'LI', 'PRE', 'CODE', 'EM']),
                SEMANTIC_MAP: {
                    'CODE': 'code', 'PRE': 'code', 'LI': 'list-item', 'IMG': 'image',
                    'H1': 'heading', 'H2': 'heading', 'H3': 'heading'
                },
                VISUAL_COLORS: {
                    clickable: '#ff0042',
                    text: '#2196F3',
                    input: '#4CAF50',
                    heading: '#FF9800'
                }
            };
        }

        /** 1. 深度扫描（含 Shadow DOM） */
        _getAllElements(root = document) {
            let els = Array.from(root.querySelectorAll('*'));
            for (const el of els) {
                if (el.shadowRoot) {
                    els = els.concat(this._getAllElements(el.shadowRoot));
                }
            }
            return els.filter(el => {
                if (el.id === this.OVERLAY_ID || el.closest(`#${this.OVERLAY_ID}`)) return false;
                if (el.getAttribute('aria-hidden') === 'true') return false;
                return true;
            });
        }

        /** 2. 元数据与遮挡判定 */
        _getElementMeta(el) {
            const style = window.getComputedStyle(el);
            const rect = el.getBoundingClientRect();

            const isVisible = style.display !== 'none' &&
                style.visibility !== 'hidden' &&
                style.opacity !== '0' &&
                rect.width >= 2 && rect.height >= 2;

            if (!isVisible) return {isVisible: false};

            // 遮挡检测：检查中心点是否被其他元素覆盖
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            let isObscured = false;

            // 只有当坐标在视口内时才进行遮挡测试
            if (centerX > 0 && centerY > 0 && centerX < window.innerWidth && centerY < window.innerHeight) {
                const topEl = document.elementFromPoint(centerX, centerY);
                if (topEl && !el.contains(topEl) && !topEl.contains(el)) {
                    isObscured = true;
                }
            }

            const isInteractive = this.CONFIG.INTERACTIVE_TAGS.has(el.tagName) ||
                this.CONFIG.INTERACTIVE_ROLES.has(el.getAttribute('role')) ||
                style.cursor === 'pointer' ||
                el.hasAttribute('onclick');

            const hasBlockChild = Array.from(el.children).some(c => !window.getComputedStyle(c).display.includes('inline'));
            const isTextual = !isInteractive && this.CONFIG.TEXT_TAGS.has(el.tagName) && !hasBlockChild;

            return {isVisible, isInteractive, isTextual, isObscured, rect};
        }

        /** 3. 语义文本清洗 */
        _getCleanText(el, category) {
            let text = "";
            if (category === 'input' || category === 'clickable') {
                text = el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('placeholder');
                if (!text && el.id) {
                    const label = document.querySelector(`label[for="${el.id}"]`);
                    if (label) text = label.innerText;
                }
            }
            if (!text) text = el.innerText || el.textContent || "";
            return text.replace(/\s+/g, ' ').trim().slice(0, 500);
        }

        /** 4. 核心流水线 */
        run() {
            console.time("Perception-v2");
            const elements = this._getAllElements();
            const vW = window.innerWidth;
            const vH = window.innerHeight;

            let data = elements.map(el => {
                const meta = this._getElementMeta(el);
                if (!meta.isVisible || meta.isObscured) return null;
                if (!meta.isInteractive && !meta.isTextual) return null;

                let category = meta.isInteractive ?
                    (['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName) ? 'input' : 'clickable') :
                    (this.CONFIG.SEMANTIC_MAP[el.tagName] || 'text');

                const text = this._getCleanText(el, category);
                if (!text && category === 'text') return null;

                let id = el.getAttribute('data-llm-id');
                if (!id) {
                    id = String(this.uniqueIdCounter++);
                    el.setAttribute('data-llm-id', id);
                }

                return {
                    id: parseInt(id),
                    tag: el.tagName.toLowerCase(),
                    category,
                    text,
                    rect: {
                        x: Math.round(meta.rect.x),
                        y: Math.round(meta.rect.y),
                        w: Math.round(meta.rect.width),
                        h: Math.round(meta.rect.height)
                    },
                    inViewport: meta.rect.top >= 0 && meta.rect.left >= 0 && meta.rect.top <= vH && meta.rect.left <= vW
                };
            }).filter(Boolean);

            data = this._mergeTextFlow(data);
            data.sort((a, b) => (a.rect.y - b.rect.y) || (a.rect.x - b.rect.x));

            this.renderDebug(data);
            console.timeEnd("Perception-v2");
            return data;
        }

        _mergeTextFlow(items) {
            const result = [];
            for (const item of items) {
                const last = result[result.length - 1];
                if (last && item.category === 'text' && last.category === 'text') {
                    const yGap = Math.abs(item.rect.y - (last.rect.y + last.rect.h));
                    const xDiff = Math.abs(item.rect.x - last.rect.x);
                    if (yGap < 10 && xDiff < 50) {
                        last.text += " " + item.text;
                        last.rect.h = Math.max(last.rect.h, (item.rect.y + item.rect.h) - last.rect.y);
                        last.rect.w = Math.max(last.rect.w, item.rect.w);
                        continue;
                    }
                }
                result.push(item);
            }
            return result;
        }

        renderDebug(elements) {
            document.getElementById(this.OVERLAY_ID)?.remove();
            const container = document.createElement('div');
            container.id = this.OVERLAY_ID;
            Object.assign(container.style, {
                position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
                pointerEvents: 'none', zIndex: 2147483647
            });

            elements.forEach(item => {
                if (!item.inViewport) return;
                const box = document.createElement('div');
                const color = this.CONFIG.VISUAL_COLORS[item.category] || this.CONFIG.VISUAL_COLORS.text;
                Object.assign(box.style, {
                    position: 'absolute', left: `${item.rect.x}px`, top: `${item.rect.y}px`,
                    width: `${item.rect.w}px`, height: `${item.rect.h}px`,
                    border: `1px ${item.category === 'text' ? 'dashed' : 'solid'} ${color}`,
                    backgroundColor: `${color}11`
                });
                if (item.category !== 'text') {
                    const label = document.createElement('span');
                    label.innerText = `${item.id}`;
                    Object.assign(label.style, {
                        position: 'absolute', top: '-14px', left: '0', background: color,
                        color: 'white', fontSize: '9px', padding: '0 2px'
                    });
                    box.appendChild(label);
                }
                container.appendChild(box);
            });
            document.body.appendChild(container);
        }
    }

    // 运行并输出结果
    const result = new BrowserPerceiver().run();
    console.log("🚀 Agent Perception Data:", result);
    console.table(result.slice(0, 20)); // 先展示前20条
    return result;
})();