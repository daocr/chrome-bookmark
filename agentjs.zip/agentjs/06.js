(function () {
    const OVERLAY_ID = 'llm-browser-agent-overlay';
    const CONFIG = {
        MIN_WIDTH: 5,
        MIN_HEIGHT: 5,
        INTERACTIVE_TAGS: new Set(['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'DETAILS', 'SUMMARY']),
        INTERACTIVE_ROLES: new Set(['button', 'link', 'checkbox', 'menuitem', 'menuitemcheckbox', 'radio', 'tab', 'textbox', 'combobox', 'searchbox']),
        SEMANTIC_MAP: {
            'CODE': 'code', 'PRE': 'code',
            'H1': 'heading', 'H2': 'heading', 'H3': 'heading', 'H4': 'heading', 'H5': 'heading', 'H6': 'heading',
            'LI': 'list-item', 'IMG': 'image'
        },
        TEXT_TAGS: new Set(['P', 'SPAN', 'DIV', 'LABEL', 'TD', 'TH', 'B', 'STRONG', 'I', 'EM', 'FONT', 'BLOCKQUOTE', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'LI', 'PRE', 'CODE'])
    };

    let uniqueIdCounter = 1;

    // --- 工具函数 ---

    /**
     * 深度递归获取所有元素，包括 Shadow DOM 和同域 Iframe
     */
    function getDeepAllElements(root = document) {
        let items = [];
        const all = root.querySelectorAll('*');
        for (const el of all) {
            if (el.id === OVERLAY_ID || el.closest(`#${OVERLAY_ID}`)) continue;
            items.push(el);
            if (el.shadowRoot) {
                items = items.concat(getDeepAllElements(el.shadowRoot));
            }
            if (el.tagName === 'IFRAME') {
                try {
                    if (el.contentDocument) {
                        items = items.concat(getDeepAllElements(el.contentDocument));
                    }
                } catch (e) {
                    // 忽略跨域 iframe
                }
            }
        }
        return items;
    }

    function isVisible(el, style, rect) {
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
        if (rect.width < 2 || rect.height < 2) return false;
        return true;
    }

    function isInteractive(el, style) {
        if (CONFIG.INTERACTIVE_TAGS.has(el.tagName)) return true;
        const role = el.getAttribute('role');
        if (role && CONFIG.INTERACTIVE_ROLES.has(role)) return true;
        if (style.cursor === 'pointer' && el.parentElement && window.getComputedStyle(el.parentElement).cursor !== 'pointer') return true;
        if (el.getAttribute('contenteditable') === 'true') return true;
        if (el.hasAttribute('tabindex') && parseInt(el.getAttribute('tabindex')) >= 0) return true;
        return false;
    }

    function getElementState(el) {
        const state = {};
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') {
            state.value = el.value;
            if (el.type === 'checkbox' || el.type === 'radio') {
                state.checked = el.checked;
            }
        }
        if (el.disabled) state.disabled = true;
        if (el.tagName === 'DETAILS') state.open = el.open;
        return Object.keys(state).length > 0 ? state : null;
    }

    function getElementLabel(el, isInput) {
        let text = "";
        if (isInput) {
            if (el.id) {
                const labelEl = document.querySelector(`label[for="${el.id}"]`);
                if (labelEl) text = labelEl.innerText;
            }
            text = text || el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.value;
        } else {
            text = el.innerText || el.textContent;
        }
        return String(text || "").replace(/[\n\r]+/g, ' ').replace(/\s{2,}/g, ' ').trim().slice(0, 1000);
    }

    // --- 核心扫描逻辑 ---

    function scanPage() {
        console.time("PerceptionScan");
        const allElements = getDeepAllElements(document);
        let rawData = [];
        const scrollX = window.scrollX;
        const scrollY = window.scrollY;

        allElements.forEach(el => {
            let style, rect;
            try {
                style = window.getComputedStyle(el);
                rect = el.getBoundingClientRect();
            } catch (e) { return; }

            if (!isVisible(el, style, rect)) return;

            const interactive = isInteractive(el, style);
            const category = interactive ? ((el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') ? 'input' : 'clickable') :
                (CONFIG.SEMANTIC_MAP[el.tagName] || 'text');

            if (category === 'text' && (!el.innerText || el.innerText.trim().length === 0)) return;

            let llmId = el.getAttribute('data-llm-id');
            if (!llmId) {
                llmId = String(uniqueIdCounter++);
                el.setAttribute('data-llm-id', llmId);
            }

            rawData.push({
                id: llmId,
                tag: el.tagName.toLowerCase(),
                category: category,
                text: getElementLabel(el, category === 'input'),
                state: getElementState(el),
                rect: {
                    x: Math.round(rect.left + scrollX),
                    y: Math.round(rect.top + scrollY),
                    w: Math.round(rect.width),
                    h: Math.round(rect.height)
                },
                isVisibleNow: (rect.top >= 0 && rect.top <= window.innerHeight)
            });
        });

        // --- 关键修复：在返回和绘图前，按 ID 数字大小进行排序 ---
        const processedData = rawData.sort((a, b) => parseInt(a.id) - parseInt(b.id));

        console.log(`[Perception] 识别并排序完成: ${processedData.length} 个元素`);
        console.timeEnd("PerceptionScan");
        return processedData;
    }

    // --- 可视化层 ---
    function drawBoundingBoxes(elements) {
        const existingOverlay = document.getElementById(OVERLAY_ID);
        if (existingOverlay) existingOverlay.remove();

        const overlay = document.createElement('div');
        overlay.id = OVERLAY_ID;
        Object.assign(overlay.style, {
            position: 'fixed', top: '0', left: '0', width: '100vw', height: '100vh',
            zIndex: '2147483647', pointerEvents: 'none'
        });

        elements.forEach(item => {
            const {x, y, w, h} = item.rect;
            // 绘图时需将绝对坐标转换回视口坐标
            const vx = x - window.scrollX;
            const vy = y - window.scrollY;

            // 仅绘制在视口附近的框，避免渲染冗余
            if (vy < -h || vy > window.innerHeight + 100) return;

            const box = document.createElement('div');
            const color = (item.category === 'clickable' || item.category === 'input') ? '#ff0042' : '#2196F3';

            Object.assign(box.style, {
                position: 'absolute', left: `${vx}px`, top: `${vy}px`, width: `${w}px`, height: `${h}px`,
                border: `1px ${item.category === 'text' ? 'dashed' : 'solid'} ${color}`,
                boxSizing: 'border-box'
            });

            if (item.category !== 'text') {
                const label = document.createElement('div');
                label.innerText = item.id;
                Object.assign(label.style, {
                    position: 'absolute', top: '-16px', left: '-1px',
                    backgroundColor: color, color: 'white', fontSize: '9px',
                    padding: '0 2px', lineHeight: '12px', fontWeight: 'bold'
                });
                box.appendChild(label);
            }
            overlay.appendChild(box);
        });
        document.body.appendChild(overlay);
    }

    const data = scanPage();
    drawBoundingBoxes(data);
    return data;
})();