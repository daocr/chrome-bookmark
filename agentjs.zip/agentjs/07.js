(function () {
    const OVERLAY_ID = 'llm-browser-agent-overlay';
    const CONFIG = {
        INTERACTIVE_TAGS: new Set(['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'DETAILS', 'SUMMARY']),
        INTERACTIVE_ROLES: new Set(['button', 'link', 'checkbox', 'menuitem', 'menuitemcheckbox', 'radio', 'tab', 'textbox', 'combobox', 'searchbox']),
        SEMANTIC_MAP: {
            'CODE': 'code', 'PRE': 'code', 'H1': 'heading', 'H2': 'heading', 'H3': 'heading',
            'H4': 'heading', 'H5': 'heading', 'H6': 'heading', 'LI': 'list-item', 'IMG': 'image'
        }
    };

    let uniqueIdCounter = 1;
    // 用于存储当前在视口内的元素 ID
    const visibleElementIds = new Set();

    // --- 1. 初始化 IntersectionObserver ---
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            const id = entry.target.getAttribute('data-llm-id');
            if (entry.isIntersecting) {
                visibleElementIds.add(id);
            } else {
                visibleElementIds.delete(id);
            }
        });
    }, {
        threshold: 0.1, // 元素出现 10% 即视为可见
        rootMargin: '0px 0px 100px 0px' // 向下预留 100px 的缓冲，防止滚动太快感知不到
    });

    // --- 2. 增强型工具函数 ---
    function getDeepAllElements(root = document) {
        let items = [];
        const all = root.querySelectorAll('*');
        for (const el of all) {
            if (el.id === OVERLAY_ID || el.closest(`#${OVERLAY_ID}`)) continue;

            // 自动打 ID 并开始观察
            let llmId = el.getAttribute('data-llm-id');
            if (!llmId) {
                llmId = String(uniqueIdCounter++);
                el.setAttribute('data-llm-id', llmId);
                observer.observe(el); // 核心：让浏览器盯住这个元素
            }

            items.push(el);
            if (el.shadowRoot) items = items.concat(getDeepAllElements(el.shadowRoot));
            if (el.tagName === 'IFRAME') {
                try {
                    if (el.contentDocument) items = items.concat(getDeepAllElements(el.contentDocument));
                } catch (e) {
                }
            }
        }
        return items;
    }

    function isInteractive(el, style) {
        if (CONFIG.INTERACTIVE_TAGS.has(el.tagName)) return true;
        const role = el.getAttribute('role');
        return (role && CONFIG.INTERACTIVE_ROLES.has(role)) || style.cursor === 'pointer';
    }

    // --- 3. 结合后的扫描逻辑 ---
    function scanVisiblePage() {
        console.time("SmartScan");
        const allElements = getDeepAllElements(document);
        let rawData = [];
        const scrollX = window.scrollX;
        const scrollY = window.scrollY;

        allElements.forEach(el => {
            const llmId = el.getAttribute('data-llm-id');

            // 核心过滤：仅处理 Observer 标记为可见的元素
            if (!visibleElementIds.has(llmId)) return;

            let style, rect;
            try {
                style = window.getComputedStyle(el);
                rect = el.getBoundingClientRect();
            } catch (e) {
                return;
            }

            // 基础可见性二次校验
            if (style.display === 'none' || style.visibility === 'hidden' || rect.width < 2) return;

            const interactive = isInteractive(el, style);
            const category = interactive ? ((el.tagName.includes('INPUT') || el.tagName === 'TEXTAREA') ? 'input' : 'clickable') :
                (CONFIG.SEMANTIC_MAP[el.tagName] || 'text');

            // 过滤无文本的非交互元素
            if (category === 'text' && (!el.innerText || el.innerText.trim().length === 0)) return;

            rawData.push({
                id: llmId,
                category: category,
                text: (el.innerText || el.getAttribute('placeholder') || "").trim().slice(0, 500),
                rect: {
                    x: Math.round(rect.left + scrollX),
                    y: Math.round(rect.top + scrollY),
                    w: Math.round(rect.width),
                    h: Math.round(rect.height)
                }
            });
        });

        // 按 ID 排序输出
        const sortedData = rawData.sort((a, b) => parseInt(a.id) - parseInt(b.id));
        console.timeEnd("SmartScan");
        return sortedData;
    }

    // --- 4. 可视化绘制 ---
    function draw(elements) {
        const existing = document.getElementById(OVERLAY_ID);
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.id = OVERLAY_ID;
        Object.assign(overlay.style, {
            position: 'fixed', top: '0', left: '0', width: '100vw', height: '100vh',
            zIndex: '2147483647', pointerEvents: 'none'
        });

        elements.forEach(item => {
            const box = document.createElement('div');
            const vx = item.rect.x - window.scrollX;
            const vy = item.rect.y - window.scrollY;

            Object.assign(box.style, {
                position: 'absolute',
                left: `${vx}px`,
                top: `${vy}px`,
                width: `${item.rect.w}px`,
                height: `${item.rect.h}px`,
                border: `1px solid ${item.category === 'text' ? '#2196F3' : '#ff0042'}`,
                backgroundColor: item.category === 'text' ? 'transparent' : 'rgba(255,0,66,0.1)'
            });

            const label = document.createElement('span');
            label.innerText = item.id;
            Object.assign(label.style, {
                position: 'absolute', top: '-14px', background: '#ff0042', color: '#fff', fontSize: '10px'
            });
            box.appendChild(label);
            overlay.appendChild(box);
        });
        document.body.appendChild(overlay);
    }

    // 执行并返回
    const visibleData = scanVisiblePage();
    draw(visibleData);
    return visibleData;
})();