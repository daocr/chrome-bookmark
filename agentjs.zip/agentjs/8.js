(function () {
    const OVERLAY_ID = 'llm-browser-agent-canvas';
    let uniqueIdCounter = 1;

    // --- 配置 ---
    const CONFIG = {
        MIN_WIDTH: 5,
        MIN_HEIGHT: 5,
        // 交互元素我们需要特别关注
        INTERACTIVE_TAGS: new Set(['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'DETAILS', 'SUMMARY']),
        INTERACTIVE_ROLES: new Set(['button', 'link', 'checkbox', 'menuitem', 'radio', 'tab', 'textbox', 'combobox', 'searchbox', 'slider', 'switch']),
        // 忽略的标签 (绝对不应该画框的)
        IGNORE_TAGS: new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'IFRAME', 'SVG', 'PATH', 'META', 'HEAD', 'LINK'])
    };

    // --- 核心辅助函数 ---

    /**
     * 关键修复：判断元素是否直接包含非空的文本节点
     * 这比检查 tagName 更准确，能捕捉到所有可见文字
     */
    function hasDirectText(el) {
        // 排除输入框，因为它们由 input 逻辑处理
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return false;

        // 遍历所有子节点，寻找 Text Node
        for (let i = 0; i < el.childNodes.length; i++) {
            const node = el.childNodes[i];
            // nodeType 3 是文本节点
            if (node.nodeType === Node.TEXT_NODE) {
                // 确保不仅仅是换行符或空格
                if (node.textContent.trim().length > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 获取元素及其几何信息
     */
    function getVisibleElements(root = document, items = []) {
        const walker = document.createTreeWalker(
            root,
            NodeFilter.SHOW_ELEMENT,
            {
                acceptNode: (node) => {
                    if (node.id === OVERLAY_ID || CONFIG.IGNORE_TAGS.has(node.tagName)) {
                        return NodeFilter.FILTER_REJECT;
                    }
                    return NodeFilter.FILTER_ACCEPT;
                }
            }
        );

        let el;
        while ((el = walker.nextNode())) {
            // 1. 可见性检查
            if (!el.checkVisibility({checkOpacity: true, checkVisibilityCSS: true})) continue;

            // 2. 几何检查
            const rect = el.getBoundingClientRect();
            if (rect.width < CONFIG.MIN_WIDTH || rect.height < CONFIG.MIN_HEIGHT) continue;

            // 3. 视口剪裁 (只处理当前屏幕内的)
            if (rect.bottom < 0 || rect.top > window.innerHeight || rect.right < 0 || rect.left > window.innerWidth) continue;

            items.push({el, rect});

            // 处理 Shadow DOM
            if (el.shadowRoot) getVisibleElements(el.shadowRoot, items);
        }
        return items;
    }

    // --- 分类逻辑 (已极大增强) ---

    function categorizeElement(el, style = null) {
        const tag = el.tagName;

        // 1. 表单输入 (优先级最高)
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') {
            return {type: 'input', color: '#ff0042'}; // 红色
        }

        // 2. 交互元素 (Tag 或 Role)
        const role = el.getAttribute('role');
        if (CONFIG.INTERACTIVE_TAGS.has(tag) || (role && CONFIG.INTERACTIVE_ROLES.has(role))) {
            return {type: 'clickable', color: '#ff0042'}; // 红色
        }

        // 3. 样式交互 (cursor: pointer)
        // 只有当不仅是文本时才检查这个，避免昂贵计算
        // 放在这里作为补充
        // (为了性能，您可以选择注释掉下面这行，或者只对非Text元素检查)
        // if (!style) style = window.getComputedStyle(el);
        // if (style.cursor === 'pointer') return { type: 'clickable', color: '#ff0042' };

        // 4. *** 关键修复：直接文本检测 ***
        // 只要元素包含直接的文字内容，就视为文本块
        if (hasDirectText(el)) {
            return {type: 'text', color: '#2196F3'}; // 蓝色
        }

        return null;
    }

    function getElementLabel(el, type) {
        let text = "";
        if (type === 'input') {
            text = el.value || el.getAttribute('placeholder') || '';
        }
        // 所有的 label 获取都尝试取 text
        if (!text) {
            // 仅获取直接子文本，避免把包含的所有子元素文本都拿进来
            // cloneNode 是为了防止破坏 DOM，但这有点慢。
            // 简化版：直接取 textContent，虽然不完美但足够用
            text = el.textContent;
        }
        return String(text).replace(/[\n\r]+/g, ' ').replace(/\s{2,}/g, ' ').trim().slice(0, 50);
    }

    // --- 绘图逻辑 ---

    function scanAndDraw() {
        // 清理旧层
        const oldOverlay = document.getElementById(OVERLAY_ID);
        if (oldOverlay) oldOverlay.remove();

        // 创建 Canvas
        const canvas = document.createElement('canvas');
        canvas.id = OVERLAY_ID;
        const dpr = window.devicePixelRatio || 1;
        Object.assign(canvas.style, {
            position: 'fixed', top: '0', left: '0',
            width: '100vw', height: '100vh',
            zIndex: '2147483647', pointerEvents: 'none'
        });
        canvas.width = window.innerWidth * dpr;
        canvas.height = window.innerHeight * dpr;

        const ctx = canvas.getContext('2d');
        ctx.scale(dpr, dpr);

        // 扫描
        const elementsInfo = getVisibleElements(document);
        let processedData = [];
        const scrollX = window.scrollX;
        const scrollY = window.scrollY;

        elementsInfo.forEach(({el, rect}) => {
            const cat = categorizeElement(el);
            if (!cat) return;

            // 分配 ID
            let llmId = el.getAttribute('data-llm-id');
            if (!llmId) {
                llmId = String(uniqueIdCounter++);
                el.setAttribute('data-llm-id', llmId);
            }

            // 绘制
            const {x, y, width, height} = rect;

            // 文本用虚线，交互用实线 (可选优化视觉)
            if (cat.type === 'text') {
                ctx.setLineDash([2, 2]);
                ctx.lineWidth = 1;
            } else {
                ctx.setLineDash([]);
                ctx.lineWidth = 2;
            }

            ctx.strokeStyle = cat.color;
            ctx.strokeRect(x, y, width, height);

            // 绘制标签 ID
            ctx.fillStyle = cat.color;
            ctx.setLineDash([]);
            // 简单的标签背景
            const txtWidth = ctx.measureText(llmId).width + 6;
            ctx.fillRect(x, y - 14, txtWidth, 14);

            ctx.fillStyle = 'white';
            ctx.font = 'bold 10px Arial';
            ctx.textBaseline = 'middle';
            ctx.fillText(llmId, x + 3, y - 7);

            processedData.push({
                id: llmId,
                type: cat.type,
                text: getElementLabel(el, cat.type),
                rect: {x: Math.round(x + scrollX), y: Math.round(y + scrollY)}
            });
        });

        document.body.appendChild(canvas);
        console.log(`识别元素数量: ${processedData.length}`);
        return processedData;
    }

    return scanAndDraw();
})();