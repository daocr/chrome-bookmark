// --- 修复版自动化脚本 ---

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * 核心修复：根据坐标获取真正的 Input 元素
 * 如果点到了 DIV，就尝试去内部找 Input
 */
function getRealInput(x, y) {
    let element = document.elementFromPoint(x, y);
    if (!element) return null;

    console.log(`🔍 坐标 (${x}, ${y}) 初始命中: <${element.tagName}>`);

    // 情况1: 直接点中了 input
    if (element.tagName === 'INPUT') {
        return element;
    }

    // 情况2: 点中了包裹容器 div，尝试找内部的 input
    const innerInput = element.querySelector('input');
    if (innerInput) {
        console.log(`   👉 在 <${element.tagName}> 内部找到了 <INPUT>`);
        return innerInput;
    }

    // 情况3 (很少见): 点中了 input 内部的某个遮挡层，尝试找父级
    // 小红书有时候输入框会被 label 遮挡，这里做一个简单的向上查找
    if (element.parentElement && element.parentElement.tagName === 'INPUT') {
        return element.parentElement;
    }

    // 如果还是没找到，尝试在周围模糊搜索 (针对 React 复杂结构)
    // 这是一个保底策略：找最近的输入框
    const inputs = document.querySelectorAll('input');
    let closestInput = null;
    let minDist = Infinity;

    inputs.forEach(input => {
        const rect = input.getBoundingClientRect();
        // 计算元素中心点
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        // 计算距离
        const dist = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2));

        // 如果距离在 50px 以内，认为就是它
        if (dist < 50 && dist < minDist) {
            minDist = dist;
            closestInput = input;
        }
    });

    if (closestInput) {
        console.log(`   👉 通过距离修正找到了附近的 <INPUT>`);
        return closestInput;
    }

    return null;
}

async function simulateInput(x, y, value) {
    // 使用新的查找逻辑
    const element = getRealInput(x, y);

    if (!element || element.tagName !== 'INPUT') {
        console.error(`❌ 无法在坐标 (${x}, ${y}) 附近找到 INPUT 元素，跳过输入。`);
        return;
    }

    console.log(`✅ 锁定目标: INPUT, 准备输入: ${value}`);

    element.focus();
    element.click();

    // React/Vue 核心输入模拟
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
    nativeInputValueSetter.call(element, value);

    element.dispatchEvent(new Event('input', {bubbles: true}));
    element.dispatchEvent(new Event('change', {bubbles: true}));
    element.dispatchEvent(new Event('blur', {bubbles: true}));
}

function simulateClick(x, y) {
    const element = document.elementFromPoint(x, y);
    if (element) {
        console.log(`🖱️ 点击坐标 (${x}, ${y}) -> <${element.tagName}>`);
        element.click();
        element.dispatchEvent(new MouseEvent('mousedown', {bubbles: true}));
        element.dispatchEvent(new MouseEvent('mouseup', {bubbles: true}));
    } else {
        console.error(`❌ 未找到坐标 (${x}, ${y}) 处的按钮`);
    }
}

// --- 执行主流程 ---
(async function run() {
    console.log("🚀 开始执行修复版脚本...");

    // 1. 输入手机号
    // JSON坐标: 1152, 201 (建议Y轴微调 +10 确保不点在边框上)
    await simulateInput(1152, 215, "13128891231");

    await sleep(800);

    // 2. 输入验证码
    // JSON坐标: 1152, 265 (之前报错的地方)
    // 这里我们稍微往下挪一点点，或者依靠上面的智能查找
    await simulateInput(1152, 275, "1551");

    await sleep(800);

    // 3. 勾选协议
    // 既然知道有协议，直接尝试查找 Checkbox 元素点击可能更稳，但这里还是用坐标模拟
    // 坐标 1232 是文字位置，复选框通常在左边 20px
    simulateClick(1210, 445);

    await sleep(500);

    // 4. 点击登录按钮
    // JSON坐标: 1152, 381
    simulateClick(1152 + 50, 381 + 20);

    console.log("🏁 执行结束");
})();