(function checkFramework() {
    const results = {
        React: false,
        Vue2: false,
        Vue3: false,
        Angular: false,
        jQuery: false
    };

    // 1. 检测全局对象和 DevTools 钩子 (最快，但可能被隐藏)
    if (window.React || window.ReactDOM || window.__REACT_DEVTOOLS_GLOBAL_HOOK__) {
        results.React = true;
    }
    if (window.Vue || window.__VUE_DEVTOOLS_GLOBAL_HOOK__) {
        // 区分 Vue 版本
        if (window.Vue && window.Vue.version) {
            window.Vue.version.startsWith('2') ? results.Vue2 = true : results.Vue3 = true;
        } else {
            // 如果只有钩子，暂时认为是 Vue，后面通过 DOM 确认版本
            results.Vue2 = true;
        }
    }
    if (window.angular) results.Angular = true;
    if (window.jQuery || window.$) results.jQuery = true;

    // 2. 深度扫描 DOM 元素属性 (最准确，生产环境无法隐藏)
    // 遍历 body 下的前 3 层节点通常就够了，为了保险我们用 TreeWalker 找特征
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, null, false);
    let node;
    let limit = 200; // 限制扫描节点数，避免卡顿

    while ((node = walker.nextNode()) && limit > 0) {
        limit--;
        const props = Object.keys(node);

        // 检测 React 特征属性
        // React 17+ 会挂载 __reactFiber, __reactProps 等属性
        if (props.some(prop => prop.startsWith('__react') || prop.startsWith('_react'))) {
            results.React = true;
        }

        // 检测 Vue 特征属性
        if (node.__vue__) {
            results.Vue2 = true;
        }
        if (node.__vue_app__) {
            results.Vue3 = true;
            results.Vue2 = false; // 修正之前的误判
        }
    }

    // 3. 输出结果
    console.group('%c 🕵️‍♂️ 框架检测报告 ', 'background: #222; color: #bada55; font-size: 14px; padding: 4px;');

    let found = false;
    if (results.React) {
        console.log('%c ⚛️ 当前页面使用 React ', 'color: #61dafb; font-weight: bold; font-size: 14px;');
        found = true;
    }
    if (results.Vue3) {
        console.log('%c 🟢 当前页面使用 Vue 3 ', 'color: #42b883; font-weight: bold; font-size: 14px;');
        found = true;
    } else if (results.Vue2) {
        console.log('%c 🟢 当前页面使用 Vue 2 ', 'color: #42b883; font-weight: bold; font-size: 14px;');
        found = true;
    }
    if (results.Angular) {
        console.log('%c 🅰️ 当前页面使用 Angular ', 'color: #dd0031; font-weight: bold; font-size: 14px;');
        found = true;
    }
    if (results.jQuery) {
        console.log('%c 💲 当前页面使用 jQuery ', 'color: #f7df1e; font-weight: bold; font-size: 12px;');
        // jQuery 不互斥，所以不标记 found = true 结束判断
    }

    if (!found) {
        console.log('%c 🤷 未检测到主流框架 (可能是 SSR, Svelte, 原生 JS 或 iframe 隔离) ', 'color: #ccc;');
    }

    console.groupEnd();
})();