import RBush from 'rbush';

// 1. 初始化 R-Tree
// 注意：rbush 默认 maxEntries 是 9，你可以根据需要调整，例如 new RBush(16)
const tree = new RBush();

// 模拟数据 (minX, minY, maxX, maxY)
// 必须包含 minX, minY, maxX, maxY 这四个属性
const rectangles = [
    { id: 'A', minX: 0, minY: 0, maxX: 100, maxY: 100, area: 10000 },
    { id: 'B', minX: 10, minY: 10, maxX: 50, maxY: 50, area: 1600 },
    { id: 'C', minX: 20, minY: 20, maxX: 30, maxY: 30, area: 100 },
    { id: 'D', minX: 60, minY: 60, maxX: 80, maxY: 80, area: 400 },
    { id: 'E', minX: 90, minY: 90, maxX: 110, maxY: 110, area: 400 }
];

// 批量加载数据（比逐个 insert 快得多）
tree.load(rectangles);

// --- 辅助函数 ---
function contains(r1, r2) {
    return r1.minX <= r2.minX &&
        r1.minY <= r2.minY &&
        r1.maxX >= r2.maxX &&
        r1.maxY >= r2.maxY;
}

// --- 业务实现 ---

// 需求 1: 查找 Parent
function findParent(targetRect) {
    const candidates = tree.search(targetRect);
    // 过滤出包含 target 且不是 target 自己的矩形
    const potentialParents = candidates.filter(item =>
        item.id !== targetRect.id && contains(item, targetRect)
    );

    if (potentialParents.length === 0) return null;

    // 按面积从小到大排序，取最小的作为直接父级
    potentialParents.sort((a, b) => a.area - b.area);
    return potentialParents[0];
}

// 需求 2: 查找 Children (所有被包含的)
function findDescendants(targetRect) {
    const candidates = tree.search(targetRect);
    return candidates.filter(item =>
        item.id !== targetRect.id && contains(targetRect, item)
    );
}

// 需求 3: 指定范围完全覆盖了哪些矩形
function findContainedIn(range) {
    const candidates = tree.search(range);
    return candidates.filter(item => contains(range, item));
}

// 需求 4: 指定范围哪些矩形有相交 (rbush 原生功能)
function findIntersecting(range) {
    return tree.search(range);
}

// 需求 5: 查找兄弟 (简化版：也就是拥有同一个 Parent 的节点)
function findSiblings(targetRect) {
    const parent = findParent(targetRect);
    if (!parent) return [];

    // 找到父节点范围内的所有矩形
    const candidates = tree.search(parent);

    // 逻辑：在 Parent 内部 + 不是 Target 自己 + 不是 Parent 自己
    // + (重要) 它的直接父级也得是这个 Parent (防止选到侄子辈)
    // 这里的“直接父级”判断会稍微耗时，为了性能通常建议预先构建树结构
    // 这里的简化逻辑是：只要被 Parent 包含且面积小于 Parent 即可
    return candidates.filter(item =>
        item.id !== targetRect.id &&
        item.id !== parent.id &&
        contains(parent, item)
    );
}

// --- 测试执行 ---
console.log("--- 开始测试 ---");

const targetC = rectangles.find(r => r.id === 'C');
console.log(`矩形 C (${targetC.id}) 的父亲是:`, findParent(targetC)?.id); // 预期 B

const targetB = rectangles.find(r => r.id === 'B');
console.log(`矩形 B (${targetB.id}) 的父亲是:`, findParent(targetB)?.id); // 预期 A

const range = { minX: 0, minY: 0, maxX: 100, maxY: 100 };
const contained = findContainedIn(range);
console.log(`Range 完全覆盖的矩形 ID:`, contained.map(r => r.id));

console.log("--- 测试结束 ---");